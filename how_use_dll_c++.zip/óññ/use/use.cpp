﻿#include "pch.h"
#include <iostream>
#include <windows.h>
#include "DynamicLibrary.h"
//#pragma comment(lib, "DynamicLibrary.lib")

TestClass* iface = nullptr; //Указатель на обьект нашего интерфейса, инициализируем его nullptr

int main()
{
	reset:
	HMODULE hMod = LoadLibrary(L"DynamicLibrary.dll"); //Загрузим библиотеку, чтобы получить её хендл
	if (NULL == hMod) //Проверю, загружена ли библиотека, чтобы не лохонуться дальше =)
	{
		printf("Library not found! Waiting...");
		Sleep(2000);
		goto reset; //Возврат к метке лежащей до LoadLibrary, чтобы повторить попытку загрузки
	}

	
	//printf("Hmodule: %X\n", (unsigned int)hMod); //Тут я выведу адрес хендла библиотеки, чтобы как вчера не лохонуться с segmentatoin fault
	getinterfacefunc_t func = (getinterfacefunc_t)GetProcAddress(hMod, "GetClassInstance"); //Тут выполняем поиск нашей экспортируемой функции из DLL через .def файл, и получаем её указатель
	//printf("Function pointer: %X\n", (unsigned int)func); //Тут выведу опять же адрес нашей функции
	iface = (TestClass*)func(); //Вызов найденой в DLL функции по её указателю, она же нам возвращает void указатель, который мы преобразуем в наш класс
	//printf("Iface instance: %X\n", (unsigned int)iface); //Выведу адрес полученного интерфейса
	if ( nullptr == iface) //Проверю так же, не равен ли nullptr, полученный нами указатель на обьект
	{
		printf("Error getting iface!\n");
		return -100;
	}

	iface->Message("Privet!!"); //Пользуемся методами класса лежащего в другой DLL, и охуеваем от происходящего )))
	iface->MessagePrint("HI");


	void (*pFunction)(const char* message);
	(FARPROC&)pFunction = GetProcAddress(hMod, "TestFunction");//getinterfacefunc_t pFunction = (getinterfacefunc_t)
	pFunction("TestFunction:::");

	return 0;
}
