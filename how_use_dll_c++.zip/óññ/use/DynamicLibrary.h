#pragma once

__declspec(dllimport) void TestFunction(const char* message);
typedef void*(*getinterfacefunc_t)();

//Exported symbol: GetClassInstance
class TestClass
{
public:
	virtual void Message(const char* text);
	virtual void MessagePrint(const char* text);
};