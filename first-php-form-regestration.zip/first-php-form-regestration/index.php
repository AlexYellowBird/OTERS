<?php
if ( (isset($_SESSION['login']) & isset($_SESSION['password'])) || (isset($_COOKIE['login']) & isset($_COOKIE['password'])) ){

    echo '<ul>';
    echo    '<li><a href="/workers/send.php">/workers/send.php</a></li>';
    echo    '<li><a href="/workers/table.php">/workers/table.php</a></li>';
    echo '</ul>';
//другую страницу
}else{
    header("Location: /connect/login.php"); //это работает
    exit();
}


?>
