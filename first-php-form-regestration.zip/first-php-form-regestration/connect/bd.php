<?php
    $link = mysqli_connect("localhost", "root", "", "id10865011_baze"); 
    //mysqli_connect('localhost', 'id10865011_user', 'password', "id10865011_baze");

    if (mysqli_connect_errno()){
        echo "<script> alert(Connect failed:" . mysqli_connect_error() . ") </script>";
        exit();
    }