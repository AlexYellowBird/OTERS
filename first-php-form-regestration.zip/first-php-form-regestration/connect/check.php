<?php

$p_ll = htmlspecialchars(trim($_POST['login'], ENT_QUOTES));
$p_aa = htmlspecialchars(trim($_POST['password'], ENT_QUOTES));

$err = []; // очистка

//  проверки пароля и логина 
if(($p_ll | $p_aa) != NULL){

    // if(count($p_ll) < 6){ // КОДИРОВКИ (языки)
    //     $err += ['name' => "Логин должен быть больше 6 символов."];
    // }
    // if(count($p_aa) < 3){
    //     $err += ['err_pass' => "Пароль должен быть больше 3 символов."];
    // }
}else{
    if(!$p_ll){
        $err += ['name' => 'Введите корректное имя.'];
    }
    if(!$p_aa){
        $err += ['err_pass' => 'Введите корректный пароль.'];
    }
}