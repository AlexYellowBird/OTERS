<?php
//
//      $hash_pass = password_hash($p_aa, PASSWORD_DEFAULT);
//


if(isset($_POST['REG'])){
require_once('connect/bd.php');
require_once('connect/check.php');

//проверка повторного пароля
$p_r_aa = htmlspecialchars(trim($_POST['rep_password'], ENT_QUOTES));
    if($p_r_aa != NULL){
        if($p_r_aa != $p_aa){
            $err += ['err_rep_pass' => 'Пароли не совпадают'];
        }
    }else{
        $err += ['err_rep_pass' => 'Введите пароль повторно.'];
    }


    if(!isset($err['name']) & !isset($err['err_rep_pass']) & !isset($err['err_pass'])){

        //чек логина
        $check_l = mysqli_query($link, "SELECT `ID` FROM `users` WHERE 'LOGIN'='$p_ll'  ");
        if(mysqli_num_rows($check_l) > 0){
            $err += ['name' => "Пользователь с таким логином уже существует"];
        }
        if(!isset($err['name'])){
            $hash_pass = password_hash($p_aa, PASSWORD_DEFAULT);
 //Запись в бд
            $wr_l = ("INSERT INTO `users` (`LOGIN`, `PASSW`) VALUES ('$p_ll', '$hash_pass')");

            if(mysqli_query($link, $wr_l)){
                header("Location: connect/login.php");
                exit();
            }else{
                $err += ['err_rep_pass' => mysqli_error($link)];
            }
        }
    }
}

    
require_once('../main.php');
?>


<div class="div_log">
    <form action="reg.php" method="post">
        <h1>Регистрация</h1>
        <div class="l_line">
            <label>Логин: </label>
            <input type="text" name="login" placeholder="login" value="<? echo $_POST['login']; ?>"><br/>
            <? if(isset($err['name'])):  ?>
            <span class="error"><?echo $err['name']?></span> <?endif;?>
        </div><br/>
        <div class="l_line">
            <label>Пароль: </label>
            <input type="password" name="password" placeholder="password" value="<? echo $_POST['password']; ?>"><br/>
            <? if(isset($err['err_pass'])): ?>
            <span class="error"><?echo $err['err_pass']?></span> <?endif;?>
        </div>
        <div class="l_line">
            <label>Повтор пароля: </label>
            <input type="password" name="rep_password" placeholder="password"><br/>
            <? if(isset($err['err_rep_pass'])): ?>
            <span class="error"><?echo $err['err_rep_pass']?></span> <?endif;?>
        </div>
        <div>
            <button class="bt_f" name="REG" autofocus>Регистрация</button>
        </div>
    </form>

    <div id="ico_back"><a href="/connect/login.php">
        <img src="/img/left_arrow.svg" alt="icon_back">
    </a></div>
</div>
