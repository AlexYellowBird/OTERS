<?php
// if( (isset($_SESSION['login']) & isset($_SESSION['password'])) || (isset($_COOKIE['login']) & isset($_COOKIE['password'])) ){
//     header("Location: /main.php"); 
//     exit();
// }

// ЗАДАЧИ:
//  кнопка выхода с удалением куков
//

ini_set('display_errors', 1);

if(isset($_POST['REG'])){
    header("Location: reg.php");
    exit();
}



if(isset($_POST['LOG'])){
    require_once('bd.php');
    require_once('check.php');

    if(!isset($err['name']) & !isset($err['err_rep_pass']) & !isset($err['err_pass'])){
        // Сверка с базой
        //".mysqli_real_escape_string($link,)."

        $check_l = mysqli_query($link, "SELECT `ID` FROM `users` WHERE `LOGIN`='$p_ll' "); 
        if(mysqli_num_rows($check_l) == 0){
            $err += ['name' => "Неправильно набран логин."];
        }else{
            $check1 = mysqli_fetch_assoc($check_l);

            $check_p = mysqli_query($link, "SELECT `PASSW` FROM `USERS` WHERE `ID` = '".$check1['ID']."' ");
            // Можно добавить проверку на несколько паролей
            $check2 = mysqli_fetch_assoc($check_p);

            if (password_verify($p_aa, $check2['PASSW'])) {

                // Запись в сэссию
                session($p_ll, $p_aa, $err);

                // Проверка для куков
                if(!isset($err['cook'])){
                    header("Location: ../workers/send.php");
                    exit();
                }

            } else {
                $err += ['err_pass' => "Неверный пароль."];
            }
        }   
    }
}

function session($p_ll, $p_aa, &$err){
    // try{
        session_start();
        $_SESSION['login'] = $p_ll;
        $_SESSION['password'] = $p_aa;
    // }catch(Exeption $e){  
    //     $err += ['cook' => $e];
    // }
        
    if(isset($_POST['remember'])){
        setcookie('login', $p_ll, time() + 60 * 60 * 24);
        setcookie('password', $p_aa, time() + 60 * 60 * 24);
    }
};
require_once('../main.php');

?>


<div class="div_log">
    <form action="login.php" method="post">
        <h1>Вход</h1>
        <div class="l_line">
            <label>Логин: </label>
            <input type="text" name="login"  placeholder="login" value="<? echo $_POST['login']; ?>"><br/>
            <? if(isset($err['name'])): ?>
            <span class="error"><?echo $err['name']?></span> <?endif;?>
        </div><br/>
        <div class="l_line">
            <label>Пароль: </label>
            <input type="password" name="password"  placeholder="password" value="<? echo $_POST['password']; ?>"><br/>
            <? if(isset($err['err_pass'])): ?>
            <span class="error" ><?echo $err['err_pass']?></span> <?endif;?>
        </div>
        <div>
            <label><input type="checkbox" name="remember" <? if(isset($_POST['remember'])){?> checked="checked" <?}?> />&nbsp;Запомнить меня</label>
        </div>
        <? if(isset($err['cook'])): ?>
            <span class="error"><?echo $err['cook']?></span> <?endif;?>
        <div>
            <button class="bt_f" name="LOG" autofocus>Войти</button>
            <button class="bt_f" action="reg.php" name="REG">Регистрация</button>
        </div>
    </form>
</div>
