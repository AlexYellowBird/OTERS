<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" type="text/css" href="/css.css">
    <script src="/bg.js"></script>
    <title>MY_Site</title>
</head>
<body>

<div id="top_case">
        <?php
            if( (isset($_SESSION['login']) & isset($_SESSION['password'])) || (isset($_COOKIE['login']) & isset($_COOKIE['password'])) ){
                echo '<form action="../main.php" method="Post"><button name="exit" id="exit" class="bt_f">EXIT</button></form>';
            
                if(isset($_POST['exit'])){
                    session_destroy();
                    if(isset($_COOKIE['login']) & isset($_COOKIE['password'])){
                        setcookie('login', $_COOKIE['login'], time() - 60 * 60 * 24);
                        setcookie('password', $_COOKIE['password'], time() - 60 * 60 * 24);
                    }
                }
            }
        ?>
        <div id="selectBg">
            <label>Background: </label>
            <select name="bg">
                <option value="bg1">bg1</option>
                <option value="bg2">bg2</option>
                <option value="bg3">bg3</option>
            </select>
        </div>
        
        <div id="ico_close">
            <a href="javascript:void(0)">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path fill="#222" fill-rule="evenodd" d="M13.414 12l4.95-4.95-1.414-1.414-4.95 4.95-4.95-4.95L5.636 7.05l4.95 4.95-4.95 4.95 1.414 1.414 4.95-4.95 4.95 4.95 1.414-1.414-4.95-4.95z"/>
                </svg>
            </a>
        </div>

</div>
<div id="ico_slide">
        <img src="/img/up_arrow.svg" alt="">
</div>

</body>
</html>