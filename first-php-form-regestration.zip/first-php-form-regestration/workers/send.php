<?php
    require_once("../connect/bd.php");

    //select
    $sql1 = "SELECT * FROM d WHERE s_name IS NOT NULL ";
    $sql2 = "SELECT * FROM dop WHERE s_name IS NOT NULL ";
    $sql3 = "SELECT * FROM o WHERE s_name IS NOT NULL ";

    $req1 = mysqli_query($link,$sql1);
    $req2 = mysqli_query($link,$sql2);
    $req3 = mysqli_query($link,$sql3);

if(isset($_POST['p_table'])){
        header("Location: table.php");
        exit();
    }

    if(isset($_POST['butt'])){

    $f_name = $_POST['f_name'];
    $l_name = $_POST['l_name'];
    $o_name = $_POST['o_name'];

    $d = $_POST['first'];
    $dop = $_POST['second'];
    $o = $_POST['third'];

    $req4 = mysqli_query($link, "SELECT id_dic FROM d WHERE s_name = '$d'");
    $req5 = mysqli_query($link,"SELECT id_dic FROM dop WHERE s_name = '$dop'");
    $req6 = mysqli_query($link,"SELECT id_dic FROM o WHERE s_name = '$o'");

    $r_d = mysqli_fetch_array($req4);
    $r_dop = mysqli_fetch_assoc($req5);
    $r_o = mysqli_fetch_assoc($req6);

              //   ААА Я ЗА**#/$  FU**
    $rr_d = (int)$r_d['id_dic'];
    $rr_dop = (int)$r_dop['id_dic'];
    $rr_o = (int)$r_o['id_dic'];


    $sql = "INSERT INTO workers (`f`, `n`, `s`, `d`, `dop`, `o`) VALUES ('$f_name', '$l_name', '$o_name', '$rr_d', '$rr_dop', '$rr_o')";
    
    if(mysqli_query($link,$sql)){
        header("Location: table.php");
        exit();
    }else{
        echo "<script>alert(Error: " . mysqli_error($link) . ");</script>";
    }
}
    require_once('../main.php');
?>

<div class="div_log">
<form action="send.php" method="POST"> 
    <div>
        Имя: <input type="text" name="f_name" value="<? if(isset($f_name)){echo $f_name;} ?>" style="margin-bottom:7px;"><br/>
        Фамилия: <input type="text" name="l_name" value="<? if(isset($l_name)){echo $l_name;} ?>" style="margin-bottom:7px;"><br/>
        Отчество: <input type="text" name="o_name" value="<? if(isset($o_name)){echo $o_name;} ?>" style="margin-bottom:7px;"><br/>
    </div>
    <div>
        Должность:<select name="first">
            <? 
            while($rows = mysqli_fetch_assoc($req1)){
                echo "<option>$rows[s_name]</option>";
            }?>
        </select><br/>
        Допуски:<select name="second">
            <? 
            while($rows = mysqli_fetch_assoc($req2)){
                echo "<option>$rows[s_name]</option>";
            }?>
        </select><br/>
        Отделы:<select name="third">
            <? 
            while($rows = mysqli_fetch_assoc($req3)){
                echo "<option>$rows[s_name]</option>";
            }?>
        </select><br/>
    </div>
    <button class="bt_f" name="butt">Загрузить</button>
    <button class="bt_f" name="p_table">Таблица</button>
</form>
</div>