<?php

?>
<link rel="stylesheet" type="text/css" href="/css.css">
<style>
    table { 
        width: 300px; 
        border-collapse: collapse; 
    }
    td, th {
        padding: 3px; 
        border: 1px solid black;
    }
    th{
        background: #b0e0e6;
    }
    td{
        background: #FFF;
    }
    #mid{
        position:relative;
        display:flex;
        justify-content:center;
        text-align: center;
    }
    .bt_f{
        color:black;
        margin: 10px 10px;
        text-decoration:none;
    }
</style>

<div id="mid">
<a  href="send.php"><button class="bt_f">Назад</button></a>&nbsp
<button class="bt_f" name="tab_clear">Очистить всё</button> 
    </div>
<div id="mid">
<table>
    <tr>
        <th>id_dic</th>
        <th>Фамилия</th>
        <th>Имя</th>
        <th>Отчество</th>
        <th>Должность</th>
        <th>Допуск</th>
        <th>Отдел</th>
    </tr>
    <?
    require_once("../connect/bd.php");

    $result = mysqli_query($link, "SELECT * FROM `workers`");
    while ($rows = mysqli_fetch_assoc($result)){
        echo "<tr>";
        foreach ($rows as $key => $value){
            echo "<td>$value</td>";
        }
        echo "</tr>";
    }
    ?>
</table>
</div>